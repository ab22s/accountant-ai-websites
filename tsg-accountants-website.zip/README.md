# TSG Accountants Website

This is a static HTML/CSS website for TSG Accountants.

## Features
- Responsive design
- Embedded Calendly booking
- Embedded Chatbase AI assistant
- Informative blog section

## Deployment
You can deploy this on GitHub Pages, Netlify, or any static host.

## Folder Structure
- `index.html`: Main page
- `styles.css`: Styling
- `assets/`: (optional) for future images or scripts
